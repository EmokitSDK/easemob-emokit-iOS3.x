var searchData=
[
  ['version',['version',['../interface_e_m_client.html#ae0806b1523e5b49381660594a26d4fdf',1,'EMClient']]],
  ['videobitrate',['videoBitrate',['../interface_e_m_call_session.html#a62fd01de7914d71f78feb20af323e44e',1,'EMCallSession']]]
];
