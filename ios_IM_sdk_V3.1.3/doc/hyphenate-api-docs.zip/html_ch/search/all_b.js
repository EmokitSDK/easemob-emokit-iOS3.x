var searchData=
[
  ['makevideocall_3aerror_3a',['makeVideoCall:error:',['../protocol_i_e_m_call_manager-p.html#a8558dd8d9f29ac1baad398dbac4ca51c',1,'IEMCallManager-p']]],
  ['makevoicecall_3aerror_3a',['makeVoiceCall:error:',['../protocol_i_e_m_call_manager-p.html#a7ab0fff375d7c40ec15d0bf7bcda1dde',1,'IEMCallManager-p']]],
  ['markallmessagesasread',['markAllMessagesAsRead',['../interface_e_m_conversation.html#aa31b1ec20d525998a5ca00352227e86b',1,'EMConversation']]],
  ['markcallsession_3aissilence_3a',['markCallSession:isSilence:',['../protocol_i_e_m_call_manager-p.html#a04d8caefc9bec66691e0c50b8f1bcfc8',1,'IEMCallManager-p']]],
  ['markmessageasreadwithid_3a',['markMessageAsReadWithId:',['../interface_e_m_conversation.html#a88921d790b4252976b0cd7ca09e34133',1,'EMConversation']]],
  ['maxoccupantscount',['maxOccupantsCount',['../interface_e_m_chatroom.html#a1be7d7507769472b119c8c0c09bb2ba3',1,'EMChatroom']]],
  ['maxuserscount',['maxUsersCount',['../interface_e_m_group_options.html#a363499589cbb9040619c9a64c2ad27e9',1,'EMGroupOptions']]],
  ['members',['members',['../interface_e_m_group.html#a100605134c905e8ba3b4a24436fc0158',1,'EMGroup']]],
  ['messageid',['messageId',['../interface_e_m_message.html#a3a85be4426c1f17888b8cb614c9e537c',1,'EMMessage']]]
];
