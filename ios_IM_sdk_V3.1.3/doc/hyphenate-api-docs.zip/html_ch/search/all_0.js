var searchData=
[
  ['_5f_5fdeprecated_5fmsg',['__deprecated_msg',['../interface_e_m_chatroom.html#af833db25893fe4456b2ccd21875338b9',1,'EMChatroom::__deprecated_msg()'],['../interface_e_m_conversation.html#abaf23778a85147bceed41fb60f51c654',1,'EMConversation::__deprecated_msg()'],['../interface_e_m_group.html#a0e4c98324e81ee341255915a7471761a',1,'EMGroup::__deprecated_msg()']]]
];
