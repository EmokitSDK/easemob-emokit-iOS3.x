var searchData=
[
  ['pausevideotransfer_3a',['pauseVideoTransfer:',['../protocol_i_e_m_call_manager-p.html#a9d3ea852ca3171c6d950a3609bcea5d5',1,'IEMCallManager-p']]],
  ['pausevoiceandvideotransfer_3a',['pauseVoiceAndVideoTransfer:',['../protocol_i_e_m_call_manager-p.html#a2179ba38b6209e274877409f384deb14',1,'IEMCallManager-p']]],
  ['pausevoicetransfer_3a',['pauseVoiceTransfer:',['../protocol_i_e_m_call_manager-p.html#ad749c1d660c251d20340aab70079d66e',1,'IEMCallManager-p']]]
];
