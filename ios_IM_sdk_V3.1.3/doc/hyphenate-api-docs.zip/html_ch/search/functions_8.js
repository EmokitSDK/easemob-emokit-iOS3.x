var searchData=
[
  ['ignoregrouppush_3aignore_3a',['ignoreGroupPush:ignore:',['../protocol_i_e_m_group_manager-p.html#add5f83a1283d222a914f04d474df5964',1,'IEMGroupManager-p']]],
  ['importconversations_3a',['importConversations:',['../protocol_i_e_m_chat_manager-p.html#a4dc89b15dc572c8fa0015c4bdc5e85be',1,'IEMChatManager-p']]],
  ['importmessages_3a',['importMessages:',['../protocol_i_e_m_chat_manager-p.html#a10c9a74e983bee8ce02f329116749d77',1,'IEMChatManager-p']]],
  ['initializesdkwithoptions_3a',['initializeSDKWithOptions:',['../interface_e_m_client.html#a48545ae60b7cf02bd2099c52427a150c',1,'EMClient']]],
  ['initwithaction_3a',['initWithAction:',['../interface_e_m_cmd_message_body.html#a5ca97dd632d24e5b2c65ce7b23745644',1,'EMCmdMessageBody']]],
  ['initwithconversationid_3afrom_3ato_3abody_3aext_3a',['initWithConversationID:from:to:body:ext:',['../interface_e_m_message.html#ac4fdc3571e200a6c4d0a555b0a49974d',1,'EMMessage']]],
  ['initwithdata_3adisplayname_3a',['initWithData:displayName:',['../interface_e_m_file_message_body.html#ab5bccb18fa7577b39e28a6b9cd1dd413',1,'EMFileMessageBody']]],
  ['initwithdata_3athumbnaildata_3a',['initWithData:thumbnailData:',['../interface_e_m_image_message_body.html#ae6ef4e09771f3a3814baced8799c42df',1,'EMImageMessageBody']]],
  ['initwithdescription_3acode_3a',['initWithDescription:code:',['../interface_e_m_error.html#afee65c932ca8dad57ae1108a2a2a607f',1,'EMError']]],
  ['initwithframe_3awithsessionpreset_3a',['initWithFrame:withSessionPreset:',['../interface_e_m_call_local_view.html#a956bd5aee50bbfe29354fc3bdbfef8e4',1,'EMCallLocalView']]],
  ['initwithlatitude_3alongitude_3aaddress_3a',['initWithLatitude:longitude:address:',['../interface_e_m_location_message_body.html#af229efc7f40bef7d8589de498e51be1f',1,'EMLocationMessageBody']]],
  ['initwithlocalpath_3adisplayname_3a',['initWithLocalPath:displayName:',['../interface_e_m_file_message_body.html#a536a7a4f9d928a01d51015fa22885aec',1,'EMFileMessageBody']]],
  ['initwithtext_3a',['initWithText:',['../interface_e_m_text_message_body.html#a918b8fb211a6b75cf03202f48eea9cc8',1,'EMTextMessageBody']]],
  ['insertmessage_3a',['insertMessage:',['../interface_e_m_conversation.html#adec509d5087b169d94b2305f90580243',1,'EMConversation']]]
];
