var searchData=
[
  ['fetchchatroominfo_3aincludememberslist_3aerror_3a',['fetchChatroomInfo:includeMembersList:error:',['../protocol_i_e_m_chatroom_manager-p.html#ac3d4b37c7a52117f3dac4e269e2d0296',1,'IEMChatroomManager-p']]],
  ['fetchgroupbanslist_3aerror_3a',['fetchGroupBansList:error:',['../protocol_i_e_m_group_manager-p.html#a14f2a9c6a9840fbaedb4357ecc0c367b',1,'IEMGroupManager-p']]],
  ['fetchgroupinfo_3aincludememberslist_3aerror_3a',['fetchGroupInfo:includeMembersList:error:',['../protocol_i_e_m_group_manager-p.html#a356e2a7e17e6d0b3d6aacf7d1996ab14',1,'IEMGroupManager-p']]]
];
