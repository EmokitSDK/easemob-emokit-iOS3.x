var searchData=
[
  ['secretkey',['secretKey',['../interface_e_m_file_message_body.html#ae56d6b8868c9efe0c6a3321df980bd6c',1,'EMFileMessageBody']]],
  ['sessionid',['sessionId',['../interface_e_m_call_session.html#ab54c256c5fec397181757c9e7ff697cd',1,'EMCallSession']]],
  ['setting',['setting',['../interface_e_m_group.html#a2277b5dca3e2342d4e94b15a5d32ad88',1,'EMGroup']]],
  ['size',['size',['../interface_e_m_image_message_body.html#a6939a87d878fe756979ebf624b937657',1,'EMImageMessageBody']]],
  ['sortmessagebyservertime',['sortMessageByServerTime',['../interface_e_m_options.html#aa653fb528db133b69b3ab0a0a307dbff',1,'EMOptions']]],
  ['status',['status',['../interface_e_m_call_session.html#a7ac723de33f96d1f05777c5e53001636',1,'EMCallSession::status()'],['../interface_e_m_message.html#aa4c81d9447ac7c252f37fc7843bfdb4d',1,'EMMessage::status()']]],
  ['style',['style',['../interface_e_m_group_options.html#a620cfb9f0308ae836185dd7d9b539adf',1,'EMGroupOptions']]],
  ['subject',['subject',['../interface_e_m_chatroom.html#a2b263c417b4ed0df7db664dc8b2182ad',1,'EMChatroom::subject()'],['../interface_e_m_group.html#afbfb0e344003c967fd654764ac294527',1,'EMGroup::subject()']]]
];
