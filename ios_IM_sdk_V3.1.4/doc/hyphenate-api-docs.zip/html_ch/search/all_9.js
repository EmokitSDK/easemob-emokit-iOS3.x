var searchData=
[
  ['joinchatroom_3aerror_3a',['joinChatroom:error:',['../protocol_i_e_m_chatroom_manager-p.html#a32a8775b7719f1426e885f864464fb68',1,'IEMChatroomManager-p']]],
  ['joinpublicgroup_3aerror_3a',['joinPublicGroup:error:',['../protocol_i_e_m_group_manager-p.html#ab8a4e26cd835e7bf13a9198c20aed1ec',1,'IEMGroupManager-p']]]
];
